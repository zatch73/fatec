# Exercício
• Criar a classe funcionário que tenha como atributos: código, nome,
salário.
• Implemente os conceitos de orientação a objetos utilizados até o
momento, para isso instancie alguns funcionários e identifique
quantos tem.
• Crie um método que calcule e mostre o novo salário aplicando um
reajuste salarial a partir de um valor informado.
• Use o construtor static para predeterminar que o código do
funcionário comece de 100
• Realize 3 instâncias